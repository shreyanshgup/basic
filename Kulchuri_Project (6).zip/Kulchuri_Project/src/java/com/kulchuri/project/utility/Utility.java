/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kulchuri.project.utility;

import java.util.ArrayList;

/**
 *
 * @author DELL
 */
public class Utility {

    public static ArrayList<String> getBranches() {
        ArrayList<String> al = new ArrayList<>();
        al.add("CS");
        al.add("IT");
        al.add("ME");
        al.add("CE");
        al.add("EC");
        al.add("EX");
        
        return al;
    }

    public static ArrayList<Integer> getSemester() {
        ArrayList<Integer> al = new ArrayList<>();
        al.add(1);
        al.add(2);
        al.add(3);
        al.add(4);
        al.add(5);
        al.add(6);
        al.add(7);
        al.add(8);
        return al;
    }
}
