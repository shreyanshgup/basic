package com.kulchuri.project.group;

public class GroupBean {

    private int gpid, tid;
    private String eno1, eno2, eno3, eno4, date, ptitle,tname,gname;

    public String getTname() {
        return tname;
    }

    public String getGname() {
        return gname;
    }

    public void setGname(String gname) {
        this.gname = gname;
    }

    public void setTname(String tname) {
        this.tname = tname;
    }

    public GroupBean() {
    }

    public int getGpid() {
        return gpid;
    }

    public void setGpid(int gpid) {
        this.gpid = gpid;
    }

    public int getTid() {
        return tid;
    }

    public void setTid(int tid) {
        this.tid = tid;
    }

    public String getEno1() {
        return eno1;
    }

    public void setEno1(String eno1) {
        this.eno1 = eno1;
    }

    public String getEno2() {
        return eno2;
    }

    public void setEno2(String eno2) {
        this.eno2 = eno2;
    }

    public String getEno3() {
        return eno3;
    }

    public void setEno3(String eno3) {
        this.eno3 = eno3;
    }

    public String getEno4() {
        return eno4;
    }

    public void setEno4(String eno4) {
        this.eno4 = eno4;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getPtitle() {
        return ptitle;
    }

    public void setPtitle(String ptitle) {
        this.ptitle = ptitle;
    }

}
