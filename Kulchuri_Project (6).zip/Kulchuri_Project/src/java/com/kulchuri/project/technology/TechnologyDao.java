package com.kulchuri.project.technology;

import com.kulchuri.project.db.KulchuriDb;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class TechnologyDao {

    private Connection conn = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;

    public TechnologyDao() {

    }

    public boolean addTechnology(TechnologyBean dto) {
        boolean flag = false;
        if (conn == null) {
            conn = KulchuriDb.getCrudDb();

        }
        try {

            String query = "insert into technology(tname) values (?)";
            ps = conn.prepareStatement(query);
            ps.setString(1, dto.getTname());

            if (ps.executeUpdate() > 0) {
                flag = true;

            }

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Exception at addSubject" + e);

        } finally {
            conn = null;
            ps = null;
            return flag;

        }
    }

    public TechnologyBean getTechnology(int tid) {
        TechnologyBean dto = null;
        if (conn == null) {
            conn = KulchuriDb.getCrudDb();
        }
        try {
            String sql = "select *from technology where tid=?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, tid);
            rs = ps.executeQuery();

            while (rs.next()) {
                dto = new TechnologyBean();
                dto.setTid(rs.getInt("tid"));
                dto.setTname(rs.getString("tname"));

            }

        } catch (Exception e) {
            System.out.println("Exception at addGroup():" + e);
        } finally {
            return dto;
        }
    }

    public ArrayList<TechnologyBean> getAllTechnologies() {
        TechnologyBean dto = null;
        ArrayList<TechnologyBean> al = new ArrayList<>();
        if (conn == null) {
            conn = KulchuriDb.getCrudDb();
        }
        try {
            String sql = "select * from technology";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                dto = new TechnologyBean();
                dto.setTid(rs.getInt("tid"));
                dto.setTname(rs.getString("tname"));
                al.add(dto);
            }
            
            
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Exception at getAllTechnologies():" + e);
        } finally {
            if (al.isEmpty()) {
                al = null;
            }
            rs = null;
            ps = null;
            conn = null;
            return al;
        }
        
    }

    public boolean deleteTechnology(int tid) {
        boolean flag = false;
        if (conn == null) {
            conn = KulchuriDb.getCrudDb();
        }
        try {
            String sql = "delete from technology where tid=?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, tid);
            ps.executeUpdate();

        } catch (Exception e) {
            System.out.println("Exception at deleteStudent():" + e);
        } finally {
            return flag;
        }
    }

    public boolean updateTechnology(TechnologyBean bean) {
        boolean flag = false;

        if (conn == null) {
            conn = KulchuriDb.getCrudDb();
        }
        try {

            String sql = "update technology set tname=? where tid=?";
            ps = conn.prepareStatement(sql);

            ps.setString(1, bean.getTname());
            ps.setInt(2, bean.getTid());

            if (ps.executeUpdate() > 0) {
                flag = true;
            }

        } catch (Exception e) {
            System.out.println("Exception at updateTechnology():" + e);
        } finally {
            return flag;
        }
    }



 public static void main(String[] args) {
   System.out.println(new TechnologyDao().getAllTechnologies());
 }
}
