package com.kulchuri.kfms.batch;

import com.kulchuri.kfms.db.KFMSDb;
import java.sql.*;
import java.util.ArrayList;

public class BatchDao {
    
    private Connection conn = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;
    
    public BatchDao() {
        
    }
    
    public boolean addBatch(BatchDto dto) {
        boolean flag = false;
        if (conn == null) {
            conn = KFMSDb.getCrudDb();
        }
        String query = "insert into batch(sid,timing,date) values(?,?,?)";
        try {
            
            ps = conn.prepareStatement(query);
            ps.setInt(1, dto.getSid());
            ps.setString(2, dto.getTiming());
            ps.setString(3, dto.getDate());
            if (ps.executeUpdate() > 0) {
                flag = true;
            }
            
        } catch (Exception e) {
            System.out.println("Exception at addBatch():" + e);
            
        } finally {
            conn = null;
            ps = null;
            return flag;
        }
    }
    
    public ArrayList<BatchDto> getAllBatches() {
        ArrayList<BatchDto> al = new ArrayList<>();
        if (conn == null) {
            conn = KFMSDb.getCrudDb();
        }
        try {
//            ps = conn.prepareStatement("select *from batch");
            ps = conn.prepareStatement("SELECT b.*, s.name FROM batch b,subject s where b.sid=s.sid");
            rs = ps.executeQuery();
            BatchDto dto;
            while (rs.next()) {
                dto = new BatchDto();
                dto.setBid(rs.getInt("bid"));
                dto.setTiming(rs.getString("timing"));
                dto.setDate(rs.getString("date"));
                dto.setSid(rs.getInt("sid"));
                dto.setName(rs.getString("name"));
                al.add(dto);
            }
        } catch (Exception e) {
            System.out.println("Exception at getAllBatches():" + e);
        } finally {
            rs = null;
            ps = null;
            conn = null;
            if (al.isEmpty()) {
                al = null;
            }
            return al;
        }
    }
    
    public ArrayList<BatchDto> getAllBatchesBySubject(int sid) {
        ArrayList<BatchDto> al = new ArrayList<>();
        if (conn == null) {
            conn = KFMSDb.getCrudDb();
        }
        try {
            ps = conn.prepareStatement("select *from batch where sid=?");
            ps.setInt(1, sid);
            rs = ps.executeQuery();
            BatchDto dto;
            while (rs.next()) {
                dto = new BatchDto();
                dto.setBid(rs.getInt("bid"));
                dto.setTiming(rs.getString("timing"));
                dto.setDate(rs.getString("date"));
                dto.setSid(rs.getInt("sid"));
                al.add(dto);
            }
        } catch (Exception e) {
            System.out.println("Exception at getAllBatchesBySubject():" + e);
        } finally {
            rs = null;
            ps = null;
            conn = null;
            if (al.isEmpty()) {
                al = null;
            }
            return al;
        }
    }
}
