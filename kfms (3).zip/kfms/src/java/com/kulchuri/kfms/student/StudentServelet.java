package com.kulchuri.kfms.student;

import java.lang.*;
import java.util.*;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet(urlPatterns = {"/student"})
@MultipartConfig(maxFileSize = 1234567899)
public class StudentServelet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        try {
            String name = req.getParameter("name");
            String bid = req.getParameter("bid");
            int s = Integer.parseInt(bid);
            String email = req.getParameter("email");
            String mno = req.getParameter("mno");
            String address = req.getParameter("address");
            Part part = req.getPart("photo");
            InputStream photo = part.getInputStream();
            String dob=req.getParameter("dob");
               
            StudentDto dto = new StudentDto();
            dto.setName(name);
            dto.setBid(s);
            dto.setEmail(email);
            dto.setMno(mno);
            dto.setAddress(address);
              dto.setDob(dob);
            StudentDao dao = new StudentDao();
            int sid = dao.addStudent(dto, photo);
            if (sid>0) {
                resp.sendRedirect("payFees.jsp?sid="+sid);
            } else {
                resp.sendRedirect("addStudent.jsp");
            }
        } catch (Exception e) {

            System.out.println(e);

        }
    }


 protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //    super.doGet(req, resp); //To change body of generated methods, choose Tools | Templates.
        String sno = req.getParameter("sid");
        int sid = Integer.parseInt(sno);
        StudentDao dao = new StudentDao();
        dao.deleteStudent(sid);
        resp.sendRedirect("viewAllStudents.jsp");

    }

}
